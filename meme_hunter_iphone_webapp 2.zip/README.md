# Meme Hunter AI — kostenlose iPhone-Web-App

## Dateien
- `index.html`: responsive Web-App, ohne Framework oder Build-Schritt.
- `worker.js`: kostenloser Cloudflare-Worker als API-Weiterleitung für DEX Screener.

## Kostenlos online stellen (GitHub Pages + Cloudflare Workers)
1. Kostenloses Konto bei https://dash.cloudflare.com/ erstellen. Unter **Workers & Pages** einen Worker erstellen (z. B. `meme-hunter-api`), Standardcode durch den Inhalt von `worker.js` ersetzen und **Deploy** wählen. Die öffentliche URL kopieren, z. B. `https://meme-hunter-api.DEIN-NAME.workers.dev`.
2. `index.html` in einem Texteditor öffnen und `REPLACE_WITH_YOUR_WORKER_URL` durch diese URL ersetzen (ohne abschließenden `/`). Speichern.
3. Kostenloses GitHub-Konto erstellen: https://github.com/ . Neues **öffentliches** Repository erstellen, z. B. `meme-hunter`. Die geänderte `index.html` in die oberste Ebene hochladen.
4. Im Repository **Settings → Pages → Build and deployment → Deploy from a branch**, Branch `main`, Ordner `/ (root)` auswählen und speichern. Die veröffentlichte URL ist normalerweise `https://DEIN-NAME.github.io/meme-hunter/`.
5. URL in Safari am iPhone öffnen → Teilen → **Zum Home-Bildschirm**. Die Seite funktioniert wie eine App, solange Internet vorhanden ist.

Die Menütexte bei Cloudflare/GitHub können sich ändern. Die App aktualisiert nur, solange die Seite im Vordergrund offen ist. Keine Push-Nachrichten und kein 24/7-Hintergrundscanner.

## Einschränkungen
DEX Screener `token-profiles/latest/v1` zeigt eine begrenzte Auswahl zuletzt erfasster Token-Profile, nicht alle Solana-Neustarts. `tokens/v1/solana/{addresses}` liefert Pools dieser Tokens. Die Quelle kann fehlen, gedrosselt werden oder ihr Schema ändern. Kostenloses Cloudflare Worker Kontingent und DEX-Screener-Ratenlimits gelten. Der Score ist nur eine einfache Heuristik, keine KI-Prognose und keine Sicherheitszertifizierung. Rugcheck-Link dient nur zur manuellen Prüfung. Keine Wallet-Verbindung, keine automatische Order, keine Renditegarantie.

## Datenschutz
Es werden keine privaten Schlüssel oder Walletdaten erfragt. Die Webseite lädt Kursdaten über deinen Cloudflare Worker. Beim Aufruf externer Links gelten die Datenschutzbestimmungen der jeweiligen Anbieter.
